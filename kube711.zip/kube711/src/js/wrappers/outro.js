
    window.Kube = window.$K = $K;
}());